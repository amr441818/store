const products = [
  {
    id: "1",
    name: "FORMAL FUNCTIONAL SHIRT",
    price: 799,
    color: "white",
    discription:
      "SLIM FIT SHIRT FEATURING A SPREAD COLLAR LONG SLEEVES WITH BUTTONED CUFFS AND A BUTTON-UP FRONT",
  },
];
